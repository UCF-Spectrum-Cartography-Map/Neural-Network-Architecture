"""Test driver for the GNN node: plays a test-split map as if a rover were driving through it.

Publishes the map's true path loss along a random walk (or at random pixels) on rf/samples,
and scores every map the GNN node publishes against the ground truth (same metrics as the
offline benchmark: RMSE on unobserved, non-building pixels, and emitter error).
"""
import numpy as np
import pandas as pd
import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile
from geometry_msgs.msg import PointStamped
from std_msgs.msg import Float32MultiArray

from .core import H, W


class ReplayNode(Node):
    def __init__(self):
        super().__init__("rf_replay")
        p = self.declare_parameter
        map_file = p("map_file", "").value
        self.mode = p("mode", "walk").value            # walk | uniform
        self.rate = p("samples_per_sec", 20.0).value
        self.stop_density = p("stop_density_pct", 10.0).value
        self.origin_x, self.origin_y = p("origin_x", 0.0).value, p("origin_y", 0.0).value
        self.res = p("m_per_px", 1.0).value
        self.rng = np.random.default_rng(p("seed", 0).value)

        row = pd.read_parquet(map_file, engine="pyarrow").iloc[0]
        self.env = np.asarray(row["building_mask"], np.float32).reshape(H, W)
        self.gt = np.asarray(row["path_loss"], np.float32).reshape(H, W)
        tx = np.asarray(row["tx_origin"], np.float32).reshape(H, W)
        self.tx_rc = np.unravel_index(int(np.argmax(tx)), tx.shape)

        self.free = np.argwhere(self.env < 0.5)
        self.pos = self.free[self.rng.integers(len(self.free))]
        self.sampled = np.zeros((H, W), bool)

        self.pub = self.create_publisher(PointStamped, "rf/samples", 100)
        latched = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(Float32MultiArray, "gnn/path_loss_map", self.on_map, latched)
        self.timer = self.create_timer(1.0 / self.rate, self.step)
        self.get_logger().info(f"replaying {map_file} ({self.mode}), true emitter at px {tuple(map(int, self.tx_rc))}")

    def next_pixel(self):
        if self.mode == "uniform":
            return self.free[self.rng.integers(len(self.free))]
        for _ in range(20):  # random walk that stays out of buildings
            dr, dc = [(0, 1), (0, -1), (1, 0), (-1, 0)][self.rng.integers(4)]
            r, c = self.pos[0] + dr, self.pos[1] + dc
            if 0 <= r < H and 0 <= c < W and self.env[r, c] < 0.5:
                self.pos = np.array([r, c])
                break
        return self.pos

    def step(self):
        if self.sampled.mean() * 100 >= self.stop_density:
            self.timer.cancel()
            self.get_logger().info(f"reached {self.stop_density}% of pixels, stopped publishing")
            return
        r, c = self.next_pixel()
        self.sampled[r, c] = True
        msg = PointStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "map"
        msg.point.x = self.origin_x + (c + 0.5) * self.res
        msg.point.y = self.origin_y + (r + 0.5) * self.res
        msg.point.z = float(self.gt[r, c])
        self.pub.publish(msg)

    def on_map(self, msg):
        pred = np.asarray(msg.data, np.float32).reshape(H, W)
        score = (~self.sampled) & (self.env < 0.5)
        rmse = float(np.sqrt(np.mean((pred[score] - self.gt[score]) ** 2)))
        est = np.unravel_index(int(np.argmin(np.where(self.env > 0.5, np.inf, pred))), pred.shape)
        err_m = float(np.hypot(est[0] - self.tx_rc[0], est[1] - self.tx_rc[1])) * self.res
        self.get_logger().info(f"samples {self.sampled.mean() * 100:.2f}%  RMSE {rmse:.2f} dB  "
                               f"emitter error {err_m:.1f} m")


def main():
    rclpy.init()
    node = ReplayNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
